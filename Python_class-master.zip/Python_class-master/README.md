# Python_class
solution C-100
